<!DOCTYPE html>
<html>
<head>
	<title>Aplikasi Perpustakaan</title>
</head>
<body>
	<h1>Selamat Datang <?php echo $username;  ?></h1>
	<h2>Aplikasi Perpustakaan FTIK USM</h2>
	<b>Pilihan Menu :</b>
	<ol>
		<li><a href="<?=base_url('index.php/buku'); ?>">Kelola Data Buku</a></li>
		<li><a href="<?=base_url('index.php/anggota'); ?>">Kelola Data Anggota</a></li>
		<li><a href="<?=base_url('index.php/pinjam'); ?>">Transaksi Pinjam</a></li>
	</ol>
	<a href="<?=base_url('index.php/perpus/logout'); ?>">Logout</a>
</body>
</html>